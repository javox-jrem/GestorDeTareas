import java.awt.Color;
import java.io.File;
import java.io.IOException;
import javax.swing.JOptionPane;
// Clase principal que extiende JFrame para crear una ventana gráfica
public class CrearTareaPropia extends javax.swing.JFrame {
// Instancia de la clase Escalar para manipular imágenes y gráficos
    Escalar escalar = new Escalar();
     // Creación de un usuario por defecto
    public Usuario usuario= new Usuario(0,null,null,null,null);
     // Ruta base del sistema para guardar tareas
    public String userHome = "E:\\GT";
    // Directorios específicos para tareas y su lista
    private String direcTareas = userHome + "E:\\GT\\Tareas";
    private String listaTareas = userHome + "E:\\GT\\Tareas";
    // Usuario actual que interactúa con el sistema
    private Usuario UsuarioActual= new Usuario();
     // Constructor de la clase
    public CrearTareaPropia() {
        initComponents();
        // Configurar la ventana en el centro de la pantalla
        setLocationRelativeTo(null);
        escalar.escalarLabel(jLabel5, "\\imagenes\\logo.png");
        escalar.escalarLabel(ImagenUsuario, "\\imagenes\\usuario.png");
        escalar.escalarLabel(lblInicio, "\\imagenes\\Inicio.png");
        escalar.escalarLabel(lblPerfil, "\\imagenes\\Perfil.png");
        escalar.escalarLabel(lblUsuarios, "\\imagenes\\Usuarios.png");
        
        escalar.escalarLabel(lblTareasActuales, "\\imagenes\\TareasActuales.png");
        escalar.escalarLabel(lblMisTareas, "\\imagenes\\MisTareas.png");
        escalar.escalarLabel(lblHistorial, "\\imagenes\\Historial.png");
        escalar.escalarLabel(lblSalir, "\\imagenes\\Salir.png");
        escalar.escalarLabel(lblFondo, "\\imagenes\\fondo5.png");
         // Obtener información del usuario actual y configurarla
        UsuarioActual=UsuarioActual.obtenerUsuarioActual();
        lblNombreUsuario.setText(UsuarioActual.getUsuario());
         // Crear la ruta específica para las tareas del usuario actual
        direcTareas = direcTareas + "\\Usuario" + UsuarioActual.getId();
        // Crear el directorio de tareas si no existe
        File archivo=new File(direcTareas);
        if(archivo.exists()==true){
            System.out.println("el archivo no pudo ser creado");
        }else{
            crearArchivos();
            System.out.println("el archivo fue creado");
        }
         // Configurar la ruta para el archivo de lista de tareas
        listaTareas = listaTareas + "\\Usuario" + UsuarioActual.getId() + "\\ListaTareas.txt";
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Menu2 = new PanelRound();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        ImagenUsuario = new javax.swing.JLabel();
        lblNombreUsuario = new javax.swing.JLabel();
        PR_Perfil = new PanelRound();
        lblPerfil = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        PR_Usuarios = new PanelRound();
        lblUsuarios = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        PR_TareasActuales = new PanelRound();
        lblTareasActuales = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        PR_MisTareas = new PanelRound();
        lblMisTareas = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        PR_Salir = new PanelRound();
        lblSalir = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        PR_Inicio = new PanelRound();
        lblInicio = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        PR_Historial = new PanelRound();
        lblHistorial = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        Pantalla = new PanelRound();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel17 = new javax.swing.JLabel();
        PRRegistro = new PanelRound();
        jLabel12 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        BT_CrearTarea = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        TF_Descripcion = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        TF_Nombre = new javax.swing.JTextField();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox5 = new javax.swing.JComboBox<>();
        BT_Atras = new javax.swing.JButton();
        CBYear = new javax.swing.JComboBox<>();
        lblFondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Menu2.setBackground(new java.awt.Color(25, 35, 60));
        Menu2.setRoundBottomLeft(50);
        Menu2.setRoundBottomRight(50);
        Menu2.setRoundTopLeft(50);
        Menu2.setRoundTopRight(50);
        Menu2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Menu2.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 160, 10));
        Menu2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 510, 120, 90));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("TASKFLOW");
        Menu2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 590, 110, 40));
        Menu2.add(ImagenUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 50, 50));

        lblNombreUsuario.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblNombreUsuario.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreUsuario.setText("Usuario");
        Menu2.add(lblNombreUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 30, 100, 30));

        PR_Perfil.setBackground(new java.awt.Color(25, 35, 60));
        PR_Perfil.setRoundBottomLeft(25);
        PR_Perfil.setRoundBottomRight(25);
        PR_Perfil.setRoundTopLeft(25);
        PR_Perfil.setRoundTopRight(25);
        PR_Perfil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PR_PerfilMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PR_PerfilMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PR_PerfilMousePressed(evt);
            }
        });
        PR_Perfil.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPerfil.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                lblPerfilComponentHidden(evt);
            }
        });
        PR_Perfil.add(lblPerfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 40, 40));

        jLabel7.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Perfil");
        PR_Perfil.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 70, 50));

        Menu2.add(PR_Perfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 200, 50));

        PR_Usuarios.setBackground(new java.awt.Color(25, 35, 60));
        PR_Usuarios.setRoundBottomLeft(25);
        PR_Usuarios.setRoundBottomRight(25);
        PR_Usuarios.setRoundTopLeft(25);
        PR_Usuarios.setRoundTopRight(25);
        PR_Usuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PR_UsuariosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PR_UsuariosMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PR_UsuariosMousePressed(evt);
            }
        });
        PR_Usuarios.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        PR_Usuarios.add(lblUsuarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 40, 40));

        jLabel8.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Usuarios");
        PR_Usuarios.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 100, 50));

        Menu2.add(PR_Usuarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 200, 50));

        PR_TareasActuales.setBackground(new java.awt.Color(25, 35, 60));
        PR_TareasActuales.setRoundBottomLeft(25);
        PR_TareasActuales.setRoundBottomRight(25);
        PR_TareasActuales.setRoundTopLeft(25);
        PR_TareasActuales.setRoundTopRight(25);
        PR_TareasActuales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PR_TareasActualesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PR_TareasActualesMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PR_TareasActualesMousePressed(evt);
            }
        });
        PR_TareasActuales.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        PR_TareasActuales.add(lblTareasActuales, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 40, 40));

        jLabel10.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Tareas actuales");
        PR_TareasActuales.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 140, 50));

        Menu2.add(PR_TareasActuales, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 200, 50));

        PR_MisTareas.setBackground(new java.awt.Color(25, 35, 60));
        PR_MisTareas.setRoundBottomLeft(25);
        PR_MisTareas.setRoundBottomRight(25);
        PR_MisTareas.setRoundTopLeft(25);
        PR_MisTareas.setRoundTopRight(25);
        PR_MisTareas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PR_MisTareasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PR_MisTareasMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PR_MisTareasMousePressed(evt);
            }
        });
        PR_MisTareas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        PR_MisTareas.add(lblMisTareas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 40, 40));

        jLabel11.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Mis Tareas");
        PR_MisTareas.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 90, 50));

        Menu2.add(PR_MisTareas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 200, 50));

        PR_Salir.setBackground(new java.awt.Color(237, 181, 94));
        PR_Salir.setRoundBottomLeft(25);
        PR_Salir.setRoundBottomRight(25);
        PR_Salir.setRoundTopLeft(25);
        PR_Salir.setRoundTopRight(25);
        PR_Salir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PR_SalirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PR_SalirMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PR_SalirMousePressed(evt);
            }
        });
        PR_Salir.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        PR_Salir.add(lblSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 40, 40));

        jLabel13.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Salir");
        PR_Salir.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 50, 50));

        Menu2.add(PR_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, 110, 50));

        PR_Inicio.setBackground(new java.awt.Color(25, 35, 60));
        PR_Inicio.setRoundBottomLeft(25);
        PR_Inicio.setRoundBottomRight(25);
        PR_Inicio.setRoundTopLeft(25);
        PR_Inicio.setRoundTopRight(25);
        PR_Inicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PR_InicioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PR_InicioMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PR_InicioMousePressed(evt);
            }
        });
        PR_Inicio.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        PR_Inicio.add(lblInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 40, 40));

        jLabel15.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Inicio");
        PR_Inicio.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 70, 50));

        Menu2.add(PR_Inicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 200, 50));

        PR_Historial.setBackground(new java.awt.Color(25, 35, 60));
        PR_Historial.setRoundBottomLeft(25);
        PR_Historial.setRoundBottomRight(25);
        PR_Historial.setRoundTopLeft(25);
        PR_Historial.setRoundTopRight(25);
        PR_Historial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PR_HistorialMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PR_HistorialMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PR_HistorialMousePressed(evt);
            }
        });
        PR_Historial.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        PR_Historial.add(lblHistorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 40, 40));

        jLabel16.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Historial");
        PR_Historial.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 90, 50));

        Menu2.add(PR_Historial, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, 200, 50));

        getContentPane().add(Menu2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 630));

        Pantalla.setBackground(new java.awt.Color(255, 255, 255));
        Pantalla.setRoundBottomRight(50);
        Pantalla.setRoundTopRight(50);
        Pantalla.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator2.setForeground(new java.awt.Color(25, 35, 60));
        Pantalla.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 690, 10));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 42)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(25, 35, 60));
        jLabel17.setText("Crear Tarea");
        Pantalla.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, -1, -1));

        PRRegistro.setBackground(new java.awt.Color(255, 255, 255, 100));
        PRRegistro.setRoundBottomLeft(35);
        PRRegistro.setRoundBottomRight(35);
        PRRegistro.setRoundTopLeft(35);
        PRRegistro.setRoundTopRight(35);
        PRRegistro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 51, 51));
        jLabel12.setText("Descripcion :");
        PRRegistro.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 150, 160, 30));

        jComboBox1.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jComboBox1.setForeground(new java.awt.Color(102, 102, 102));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mes", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        PRRegistro.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 320, 180, 40));

        BT_CrearTarea.setBackground(new java.awt.Color(255, 255, 255));
        BT_CrearTarea.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        BT_CrearTarea.setForeground(new java.awt.Color(102, 102, 102));
        BT_CrearTarea.setText("Crear Tarea");
        BT_CrearTarea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BT_CrearTareaActionPerformed(evt);
            }
        });
        PRRegistro.add(BT_CrearTarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 390, -1, -1));
        PRRegistro.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, 520, 10));
        PRRegistro.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 520, 10));

        TF_Descripcion.setBackground(new java.awt.Color(0, 0, 0,0));
        TF_Descripcion.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TF_Descripcion.setForeground(new java.awt.Color(51, 51, 51));
        TF_Descripcion.setBorder(null);
        TF_Descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TF_DescripcionActionPerformed(evt);
            }
        });
        PRRegistro.add(TF_Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 180, 520, 40));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(51, 51, 51));
        jLabel14.setText("Nombre :");
        PRRegistro.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, 120, 30));

        TF_Nombre.setBackground(new java.awt.Color(255, 255, 255,0));
        TF_Nombre.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TF_Nombre.setForeground(new java.awt.Color(51, 51, 51));
        TF_Nombre.setText("Nombre de la tarea");
        TF_Nombre.setBorder(null);
        TF_Nombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TF_NombreMousePressed(evt);
            }
        });
        TF_Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TF_NombreActionPerformed(evt);
            }
        });
        PRRegistro.add(TF_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 520, 40));

        jComboBox2.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jComboBox2.setForeground(new java.awt.Color(102, 102, 102));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Prioridad", "Baja", "Media", "Alta" }));
        PRRegistro.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 250, 210, 40));

        jComboBox3.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jComboBox3.setForeground(new java.awt.Color(102, 102, 102));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estado", "Por hacer", "En progreso", "Completada" }));
        PRRegistro.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 250, -1, 40));

        jComboBox5.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jComboBox5.setForeground(new java.awt.Color(102, 102, 102));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dia", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        jComboBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5ActionPerformed(evt);
            }
        });
        PRRegistro.add(jComboBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 320, 90, 40));

        BT_Atras.setBackground(new java.awt.Color(255, 255, 255));
        BT_Atras.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BT_Atras.setForeground(new java.awt.Color(102, 102, 102));
        BT_Atras.setText("Cancelar");
        BT_Atras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BT_AtrasActionPerformed(evt);
            }
        });
        PRRegistro.add(BT_Atras, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        CBYear.setBackground(new java.awt.Color(255, 255, 255));
        CBYear.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        CBYear.setForeground(new java.awt.Color(102, 102, 102));
        CBYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Año", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025" }));
        CBYear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBYearActionPerformed(evt);
            }
        });
        PRRegistro.add(CBYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 320, 100, 40));

        Pantalla.add(PRRegistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, 670, 470));
        Pantalla.add(lblFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, 670, 470));

        getContentPane().add(Pantalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 870, 630));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed
/**
 * Método que se ejecuta al presionar el botón "Crear Tarea".
 * Este método obtiene los datos ingresados por el usuario, valida la información
 * y, si es válida, crea una nueva tarea y la guarda en un archivo.
 * 
 * @param evt el evento de acción generado por el botón.
 */
    private void BT_CrearTareaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BT_CrearTareaActionPerformed
        String nombreTarea = TF_Nombre.getText();         // Nombre de la tarea
        String descrip = TF_Descripcion.getText();             // Descripción
        String meses = (String) jComboBox1.getSelectedItem(); // Mes asignado
        String estados = (String) jComboBox3.getSelectedItem(); // Estado
        String prioridades = (String) jComboBox2.getSelectedItem(); // Prioridad
        int dias=0;// Prioridad
        if(!jComboBox5.getSelectedItem().toString().equals("Dia"))
            dias = Integer.parseInt(jComboBox5.getSelectedItem().toString());  // Día asignado
        int year=0;
        if(!CBYear.getSelectedItem().toString().equals("Año"))
            year = Integer.parseInt(CBYear.getSelectedItem().toString()); 

        // Crear instancia de la tarea
        if(!nombreTarea.isEmpty() && !descrip.isEmpty() && !meses.equals("Mes") && !estados.equals("Estado") && !prioridades.equals("Prioridad")){
            if(!jComboBox5.getSelectedItem().toString().equals("Dia") && !CBYear.getSelectedItem().toString().equals("Año")){
                Tarea nuevaTarea = new Tarea();
                nuevaTarea.setNumeroTarea(nuevaTarea.numeroNuevaTarea(listaTareas)); // Generar número de tarea único
                nuevaTarea.setNombre(nombreTarea);
                nuevaTarea.setDescripcion(descrip);
                nuevaTarea.setMes(meses);
                nuevaTarea.setEstado(estados);
                nuevaTarea.setPrioridad(prioridades);
                nuevaTarea.setDia(dias);
                nuevaTarea.setYear(year);

                nuevaTarea.CrearNuevaTarea(direcTareas, nuevaTarea); // Crear archivo individual
                nuevaTarea.guardarTarea(direcTareas, nuevaTarea, listaTareas); // Guardar en lista general
                JOptionPane.showMessageDialog(null, "Tarea Guardada");

                // Limpieza de campos después de guardar
                TF_Nombre.setText("Nombre de la tarea");
                TF_Descripcion.setText("");
                jComboBox1.setSelectedIndex(0);
                jComboBox3.setSelectedIndex(0);
                jComboBox2.setSelectedIndex(0);
                jComboBox5.setSelectedIndex(0);
                CBYear.setSelectedIndex(0);
            }else
            {
                JOptionPane.showMessageDialog(null, "Ingrese todos los datos");
            }
        }else{
            JOptionPane.showMessageDialog(null, "Ingrese todos los datos");
        }
    }//GEN-LAST:event_BT_CrearTareaActionPerformed

    private void TF_DescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TF_DescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TF_DescripcionActionPerformed
/**
 * Método ejecutado al presionar el campo de texto del nombre de la tarea.
 * Si el campo contiene el texto predeterminado, lo limpia.
 * 
 * @param evt el evento de acción generado por el clic del mouse.
 */
    private void TF_NombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_NombreMousePressed
        if(TF_Nombre.getText().equals("Nombre de la tarea"))
        TF_Nombre.setText("");
    }//GEN-LAST:event_TF_NombreMousePressed
/**
 * Método ejecutado al interactuar con el campo de texto del nombre de la tarea.
 * 
 * @param evt el evento de acción generado por el componente.
 */
    private void TF_NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TF_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TF_NombreActionPerformed
/**
 * Método ejecutado al seleccionar una opción del JComboBox5.
 * 
 * @param evt el evento de acción generado por el componente.
 */
    private void jComboBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox5ActionPerformed
/**
 * Método ejecutado cuando el componente lblPerfil está oculto.
 * 
 * @param evt el evento generado por el cambio de visibilidad del componente.
 */
    private void lblPerfilComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_lblPerfilComponentHidden
        // TODO add your handling code here:
    }//GEN-LAST:event_lblPerfilComponentHidden

    private void PR_PerfilMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_PerfilMouseEntered
        Color color = new Color(237,181,94);
        PR_Perfil.setBackground(color);
    }//GEN-LAST:event_PR_PerfilMouseEntered

    private void PR_PerfilMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_PerfilMouseExited
        Color color = new Color(25,35,60);
        PR_Perfil.setBackground(color);
    }//GEN-LAST:event_PR_PerfilMouseExited
/**
 * Método ejecutado al presionar el componente PR_Perfil.
 * Abre la ventana de perfil y cierra la ventana actual.
 * 
 * @param evt el evento del mouse generado al presionar el componente.
 */
    private void PR_PerfilMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_PerfilMousePressed
        Perfil ventana = new Perfil();
        ventana.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_PR_PerfilMousePressed

    private void PR_UsuariosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_UsuariosMouseEntered
        Color color = new Color(237,181,94);
        PR_Usuarios.setBackground(color);
    }//GEN-LAST:event_PR_UsuariosMouseEntered

    private void PR_UsuariosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_UsuariosMouseExited
        Color color = new Color(25,35,60);
        PR_Usuarios.setBackground(color);
    }//GEN-LAST:event_PR_UsuariosMouseExited
/**
 * Abre la ventana de usuarios y cierra la ventana actual.
 * 
 * @param evt el evento del mouse generado al presionar el componente PR_Usuarios.
 */
    private void PR_UsuariosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_UsuariosMousePressed
        Usuarios ventana = new Usuarios();
        ventana.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_PR_UsuariosMousePressed

    private void PR_TareasActualesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_TareasActualesMouseEntered
        Color color = new Color(237,181,94);
        PR_TareasActuales.setBackground(color);
    }//GEN-LAST:event_PR_TareasActualesMouseEntered

    private void PR_TareasActualesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_TareasActualesMouseExited
        Color color = new Color(25,35,60);
        PR_TareasActuales.setBackground(color);
    }//GEN-LAST:event_PR_TareasActualesMouseExited
/**
 * Abre la ventana de tareas actuales y cierra la ventana actual.
 * 
 * @param evt el evento del mouse generado al presionar el componente PR_TareasActuales.
 */
    private void PR_TareasActualesMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_TareasActualesMousePressed
        TareasActuales ventana = new TareasActuales();
        ventana.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_PR_TareasActualesMousePressed

    private void PR_MisTareasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_MisTareasMouseEntered
        Color color = new Color(237,181,94);
        PR_MisTareas.setBackground(color);
    }//GEN-LAST:event_PR_MisTareasMouseEntered

    private void PR_MisTareasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_MisTareasMouseExited
        Color color = new Color(25,35,60);
        PR_MisTareas.setBackground(color);
    }//GEN-LAST:event_PR_MisTareasMouseExited
/**
 * Abre la ventana de mis tareas y cierra la ventana actual.
 * 
 * @param evt el evento del mouse generado al presionar el componente PR_MisTareas.
 */
    private void PR_MisTareasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_MisTareasMousePressed
        MisTareas ventana = new MisTareas();
        ventana.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_PR_MisTareasMousePressed

    private void PR_SalirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_SalirMouseEntered
        Color color = new Color(214,80,68);
        PR_Salir.setBackground(color);
    }//GEN-LAST:event_PR_SalirMouseEntered

    private void PR_SalirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_SalirMouseExited
        Color color = new Color(237,181,94);
        PR_Salir.setBackground(color);
    }//GEN-LAST:event_PR_SalirMouseExited
/**
 * Abre la ventana de inicio de sesión (Login) y cierra la ventana actual.
 * 
 * @param evt el evento del mouse generado al presionar el componente PR_Salir.
 */
    private void PR_SalirMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_SalirMousePressed
        Login ventana = new Login();
        ventana.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_PR_SalirMousePressed

    private void PR_InicioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_InicioMouseEntered
        Color color = new Color(237,181,94);
        PR_Inicio.setBackground(color);
    }//GEN-LAST:event_PR_InicioMouseEntered

    private void PR_InicioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_InicioMouseExited
        Color color = new Color(25,35,60);
        PR_Inicio.setBackground(color);
    }//GEN-LAST:event_PR_InicioMouseExited
/**
 * Abre la ventana de inicio y cierra la ventana actual.
 * 
 * @param evt el evento del mouse generado al presionar el componente PR_Inicio.
 */
    private void PR_InicioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_InicioMousePressed
        Inicio ventana = new Inicio();
        ventana.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_PR_InicioMousePressed

    private void PR_HistorialMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_HistorialMouseEntered
        Color color = new Color(237,181,94);
        PR_Historial.setBackground(color);
    }//GEN-LAST:event_PR_HistorialMouseEntered

    private void PR_HistorialMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_HistorialMouseExited
        Color color = new Color(25,35,60);
        PR_Historial.setBackground(color);
    }//GEN-LAST:event_PR_HistorialMouseExited
/**
 * Abre la ventana del historial y cierra la ventana actual.
 * 
 * @param evt el evento del mouse generado al presionar el componente PR_Historial.
 */
    private void PR_HistorialMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PR_HistorialMousePressed
        Historial ventana = new Historial();
        ventana.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_PR_HistorialMousePressed
/**
 * Regresa a la ventana "Mis Tareas" desde la ventana actual.
 * 
 * @param evt el evento de acción generado por el botón "Atrás".
 */
    private void BT_AtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BT_AtrasActionPerformed
        MisTareas ventana = new MisTareas();
        ventana.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BT_AtrasActionPerformed

    private void CBYearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBYearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CBYearActionPerformed
/**
 * Método que crea los archivos necesarios para gestionar las tareas.
 * Crea una carpeta en la ruta especificada por la variable `direcTareas` 
 * y un archivo de texto en la ruta especificada por `listaTareas`.
 * 
 * Si la carpeta ya existe, imprime un mensaje indicando que no se pudo crear.
 * Si el archivo ya existe, imprime su ubicación; de lo contrario, lo crea.
 * En caso de error al crear el archivo, se imprime el error en la consola.
 */
    private void crearArchivos(){
        File archivo = new File(direcTareas);
        
        if (archivo.mkdir()) {
            System.out.println(".");
        } else {
            System.out.println("No se pudo crear la carpeta.");
        }
        
        archivo = new File(listaTareas);
        
        try {
            if (archivo.createNewFile()) {
                System.out.println("Archivo creado en: " + archivo.getAbsolutePath());
            } else {
                System.out.println("El archivo ya existe en: " + archivo.getAbsolutePath());
            }
        } catch (IOException e) {
            System.out.println("Ocurrió un error al crear el archivo.");
            e.printStackTrace();
        }
    }
    /**
 * Método principal de la aplicación. 
 * Configura el estilo de apariencia gráfico para la interfaz y muestra 
 * el formulario principal de la aplicación.
 * 
 * @param args los argumentos de línea de comandos.
 */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CrearTareaPropia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CrearTareaPropia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CrearTareaPropia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CrearTareaPropia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CrearTareaPropia().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BT_Atras;
    private javax.swing.JButton BT_CrearTarea;
    private javax.swing.JComboBox<String> CBYear;
    private javax.swing.JLabel ImagenUsuario;
    private PanelRound Menu2;
    private PanelRound PRRegistro;
    private PanelRound PR_Historial;
    private PanelRound PR_Inicio;
    private PanelRound PR_MisTareas;
    private PanelRound PR_Perfil;
    private PanelRound PR_Salir;
    private PanelRound PR_TareasActuales;
    private PanelRound PR_Usuarios;
    private PanelRound Pantalla;
    private javax.swing.JTextField TF_Descripcion;
    private javax.swing.JTextField TF_Nombre;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JLabel lblFondo;
    private javax.swing.JLabel lblHistorial;
    private javax.swing.JLabel lblInicio;
    private javax.swing.JLabel lblMisTareas;
    private static javax.swing.JLabel lblNombreUsuario;
    private javax.swing.JLabel lblPerfil;
    private javax.swing.JLabel lblSalir;
    private javax.swing.JLabel lblTareasActuales;
    private javax.swing.JLabel lblUsuarios;
    // End of variables declaration//GEN-END:variables
}
