import java.io.*;
import java.util.ArrayList;
import java.util.Date;
/**
 * La clase Tarea representa una tarea en un sistema de gestión de tareas. 
 * Cada tarea tiene atributos como el número de tarea, nombre, descripción, prioridad, 
 * estado, comentario, usuario asignado, fecha de entrega y otros detalles asociados.
 */
public class Tarea {
    public int numTarea;
    public String nombre;
    public String descripcion;
    public String prioridad;
    public String estado;
    public String comentario;
    public String usuarioAsignado;
    public int dia;
    public String mes;
    public int year;
    
    /**
     * Constructor por defecto para la clase Tarea.
     */
    public Tarea(){
    }
     /**
     * Constructor para crear una tarea con todos los parámetros requeridos.
     * 
     * @param NumeroTarea El número de tarea.
     * @param Nombre El nombre de la tarea.
     * @param Descripcion La descripción de la tarea.
     * @param Prioridad La prioridad de la tarea.
     * @param UsuarioAsignado El nombre del usuario asignado a la tarea.
     * @param dia El día de la fecha de entrega.
     * @param mes El mes de la fecha de entrega.
     * @param year El año de la fecha de entrega.
     */
    public Tarea(int NumeroTarea,String Nombre,String Descripcion,String Prioridad,String UsuarioAsignado,int dia,String mes,int year){
        numTarea=NumeroTarea;
        nombre=Nombre;
        descripcion=Descripcion;
        prioridad=Prioridad;
        estado="Por hacer";
        comentario=null;
        usuarioAsignado=UsuarioAsignado;
        this.dia=dia;
        this.mes=mes;
        this.year=year;
    }
    
    public Tarea(int NumeroTarea,String Nombre,String Descripcion,String Prioridad,String UsuarioAsignado,int dia,String mes){
        numTarea=NumeroTarea;
        nombre=Nombre;
        descripcion=Descripcion;
        prioridad=Prioridad;
        estado="Por hacer";
        comentario=null;
        usuarioAsignado=UsuarioAsignado;
        this.dia=dia;
        this.mes=mes;
    }
    
    public Tarea(int NumeroTarea,String Nombre,String Descripcion,String Prioridad,String Estado,String UsuarioAsignado,int dia,String mes){
        numTarea=NumeroTarea;
        nombre=Nombre;
        descripcion=Descripcion;
        prioridad=Prioridad;
        estado=Estado;
        comentario=null;
        usuarioAsignado=UsuarioAsignado;
        this.dia=dia;
        this.mes=mes;
    }
    public Tarea(Tarea aux){
        numTarea=aux.getNumeroTarea();
        nombre=aux.getNombre();
        descripcion=aux.getDescripcion();
        prioridad=aux.getPrioridad();
        estado=aux.getEstado();
        comentario=null;
        usuarioAsignado=aux.getUsuarioAsignado();
        this.dia=aux.getDia();
        this.mes=aux.getMes();
        this.year=aux.getYear();
    }
 // Otros constructores similares con diferentes combinaciones de parámetros.

    /**
     * Obtiene el año de entrega de la tarea.
     * 
     * @return El año de entrega de la tarea.
     */
    public int getYear() {
        return year;
    }

    /**
     * Obtiene el día de la fecha de entrega de la tarea.
     * 
     * @return El día de la fecha de entrega.
     */
    public int getDia() {
        return dia;
    }
/**
     * Obtiene el mes de la fecha de entrega de la tarea.
     * 
     * @return El mes de la fecha de entrega.
     */
    public String getMes() {
        return mes;
    }
    /**
     * Obtiene el número de la tarea.
     * 
     * @return El número de la tarea.
     */

    public int getNumeroTarea(){
        return numTarea;
    } 
    /**
     * Obtiene el nombre de la tarea.
     * 
     * @return El nombre de la tarea.
     */
    public String getNombre() {
        return nombre;
    }
/**
     * Obtiene la descripción de la tarea.
     * 
     * @return La descripción de la tarea.
     */
    public String getDescripcion() {
        return descripcion;
    }
 /**
     * Obtiene la prioridad de la tarea.
     * 
     * @return La prioridad de la tarea.
     */
    public String getPrioridad() {
        return prioridad;
    }
/**
     * Obtiene el estado de la tarea.
     * 
     * @return El estado de la tarea.
     */
    public String getEstado() {
        return estado;
    }
/**
     * Obtiene el comentario asociado a la tarea.
     * 
     * @return El comentario de la tarea.
     */
    public String getComentario() {
        return comentario;
    }
/**
     * Obtiene el nombre del usuario asignado a la tarea.
     * 
     * @return El nombre del usuario asignado.
     */
    public String getUsuarioAsignado() {
        return usuarioAsignado;
    }
 /**
     * Establece el número de la tarea.
     * 
     * @param numero El nuevo número de la tarea.
     */
    public void setNumeroTarea(int numero) {
        this.numTarea = numero;
    }
    /**
     * Establece el nombre de la tarea.
     * 
     * @param nombre El nuevo nombre de la tarea.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
 /**
     * Establece la descripción de la tarea.
     * 
     * @param descripcion La nueva descripción de la tarea.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
/**
     * Establece la prioridad de la tarea.
     * 
     * @param prioridad La nueva prioridad de la tarea.
     */
    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }
 /**
     * Establece el estado de la tarea.
     * 
     * @param estado El nuevo estado de la tarea.
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
 /**
     * Establece el comentario de la tarea.
     * 
     * @param comentario El nuevo comentario de la tarea.
     */
    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
/**
     * Establece el usuario asignado a la tarea.
     * 
     * @param usuarioAsignado El nuevo usuario asignado.
     */
    public void setUsuarioAsignado(String usuarioAsignado) {
        this.usuarioAsignado = usuarioAsignado;
    }
    /**
     * Establece el día de la fecha de entrega de la tarea.
     * 
     * @param dia El nuevo día de la fecha de entrega.
     */
    public void setDia(int dia){
        this.dia=dia;
    }
    /**
     * Establece el mes de la fecha de entrega de la tarea.
     * 
     * @param mes El nuevo mes de la fecha de entrega.
     */
    public void setMes(String mes){
        this.mes=mes;
    }
    /*
     * Establece el año de la fecha de entrega de la tarea.
     * 
     * @param year El nuevo año de la fecha de entrega.
     */
    public void setYear(int year){
        this.year=year;
    }
     /**
     * Elimina una tarea de la lista de tareas y elimina su archivo asociado.
     *
     * @param direccion Ruta completa donde se encuentra el archivo de la tarea.
     * @param tarea Objeto de tipo Tarea a eliminar.
     * @param listaTareas Ruta del archivo donde se encuentra la lista de tareas.
     * @param direc Ruta del directorio donde se almacenarán los archivos temporales.
     */
    public void eliminarTarea(String direccion, Tarea tarea, String listaTareas,String direc) {
        // Elimina la tarea de la lista de tareas
        File lista = new File(listaTareas);
        String lineaABorrar = tarea.getNumeroTarea() + "|" + tarea.getNombre();

        File archivoTemporal = new File(direc+ "\\auxiliar.txt");
        try {
            

            try (BufferedReader lector = new BufferedReader(new FileReader(lista));
                 BufferedWriter escritor = new BufferedWriter(new FileWriter(archivoTemporal))) {
                String lineaActual;
                while ((lineaActual = lector.readLine()) != null) {
                    if (!lineaActual.equals(lineaABorrar)) {
                        if(!lineaActual.equals("") && !lineaActual.isEmpty()){
                            escritor.write(lineaActual);
                            escritor.newLine();
                        }
                    }
                }
            }

            
        } catch (IOException e) {
            System.out.println("Ocurrió un error al intentar eliminar la tarea.");
            e.printStackTrace();
        }
        if (lista.delete()) {
                archivoTemporal.renameTo(lista);
                System.out.println("Tarea eliminada de la lista.");
            }else{
                System.out.println("No se pudo eliminar la Tarea"+tarea.getNumeroTarea()+" de la lista");
            }

            // Elimina el archivo de la tarea
            File archivo = new File(direccion);
            if (archivo.delete()) {
                System.out.println("Archivo de tarea eliminado.");
            }else{
                System.out.println("No se pudo eliminar la Tarea"+tarea.getNumeroTarea());
                System.out.println("Resultado de delete(): " + archivo.delete());
            }
    }
     /**
     * Crea un nuevo archivo para la tarea especificada.
     *
     * @param direccion Ruta del directorio donde se creará el archivo.
     * @param act Objeto de tipo Tarea con los detalles de la tarea a crear.
     */
    public void CrearNuevaTarea (String direccion,Tarea act){
        File archivo =new File(direccion + "\\"+ act.getNumeroTarea()+".txt");
        try {
            if (archivo.createNewFile()) {
                System.out.println("Archivo creado en: " + archivo.getAbsolutePath());
            } else {
                System.out.println("El archivo ya existe en: " + archivo.getAbsolutePath());
            }
        } catch (IOException e) {
            System.out.println("Ocurrió un error al crear el archivo.");
            e.printStackTrace();
        }
    }
    /**
     * Guarda una tarea en el archivo correspondiente y en la lista de tareas.
     *
     * @param direccion Ruta del directorio donde se guardará el archivo de la tarea.
     * @param act Objeto de tipo Tarea que se guardará.
     * @param listaTareas Ruta del archivo de lista de tareas.
     */
    public void guardarTarea (String direccion,Tarea act,String listaTareas){
        File archivo=new File(direccion+"\\"+act.getNumeroTarea()+".txt");
        FileWriter escribir;
        PrintWriter linea;
        File ListaTareas=new File(listaTareas);
        
        try{
            escribir = new FileWriter(ListaTareas,true);
            linea = new PrintWriter(escribir);
            if(ListaTareas.length() == 0)
                escribir.write(act.getNumeroTarea()+"|"+act.getNombre()+"\n");
            else
                escribir.write(act.getNumeroTarea()+"|"+act.getNombre()+"\n");
            linea.close();
        }catch(IOException exepcion){
            exepcion.printStackTrace(System.out);
        }
        
        try {
            escribir = new FileWriter(archivo,true);
            linea = new PrintWriter(escribir);
            escribir.write("NumeroTarea:"+act.getNumeroTarea()+"\n");
            escribir.write("Nombre:"+act.getNombre()+"\n");
            escribir.write("Descripcion:"+act.getDescripcion()+"\n");
            escribir.write("Prioridad:"+act.getPrioridad()+"\n");
            escribir.write("Estado:"+act.getEstado()+"\n");
            escribir.write("UsuarioAsignado:"+act.getUsuarioAsignado()+"\n");
            escribir.write("Comentario:"+act.getComentario()+"\n");
            escribir.write("Dia:"+act.getDia()+"\n");
            escribir.write("Mes:"+act.getMes()+"\n");
            escribir.write("Año:"+act.getYear()+"\n");
            linea.close();
        } catch (IOException e) {
            System.out.println("Ocurrió un error al guardar la partida en el archivo: " + e.getMessage());
        }
    }
     /**
     * Obtiene los detalles de una tarea a partir de su archivo de datos.
     *
     * @param direccion Ruta del archivo donde se encuentran los detalles de la tarea.
     * @param NumeroTarea Número de la tarea a buscar.
     * @return Objeto Tarea con los detalles extraídos del archivo.
     */
    public Tarea DetallesTarea (String direccion,int NumeroTarea){
        File archivo=new File (direccion);
        String contenido=null;
        String nombre=null;
        String descripcion=null;
        String prioridad=null;
        String estado=null;
        String comentario=null;
        String usuarioAsignado=null;
        int dia=0;
        String mes= null;
        int year=0;
        
        try (BufferedReader lectura = new BufferedReader(new FileReader(archivo))) {
            contenido = lectura.readLine();
            while(contenido != null){
                if(contenido.contains("Nombre:")){
                    nombre=contenido.substring(7,contenido.length());
                }
                if(contenido.contains("Descripcion:")){
                    descripcion=contenido.substring(12,contenido.length());
                }
                if(contenido.contains("Prioridad:")){
                    prioridad=contenido.substring(10,contenido.length());
                }
                if(contenido.contains("Estado:")){
                    estado=contenido.substring(7,contenido.length());
                }
                if(contenido.contains("UsuarioAsignado:")){
                    usuarioAsignado=contenido.substring(16,contenido.length());
                }
                if(contenido.contains("Comentario:")){
                    comentario=contenido.substring(11,contenido.length());
                }
                if(contenido.contains("Dia:")){
                    String aux=contenido.substring(4,contenido.length());
                    dia=Integer.parseInt(aux);
                }
                if(contenido.contains("Mes:")){
                    mes=contenido.substring(4,contenido.length());
                }
                if(contenido.contains("Año:")){
                    String aux=contenido.substring(4,contenido.length());
                    year=Integer.parseInt(aux);
                }
                contenido = lectura.readLine();
            }
        } catch (IOException excepcion) {
            excepcion.printStackTrace();
        }
        Tarea nueva=new Tarea(NumeroTarea,nombre,descripcion,prioridad, estado,usuarioAsignado,dia,mes);
        nueva.setYear(year);
        return nueva;
    }
    /**
     * Obtiene el número para una nueva tarea, incrementando el número de la última tarea en el archivo.
     *
     * @param direccion Ruta del archivo donde se encuentra la lista de tareas.
     * @return El número de la nueva tarea.
     */
    public int numeroNuevaTarea(String direccion){
        int numero=0;
        File archivo=new File (direccion);
        String contenido="";
        Tarea aux=new Tarea();
        
        try (BufferedReader lectura = new BufferedReader(new FileReader(archivo))) {
            contenido = lectura.readLine();
            while(contenido != null){
                aux=aux.indiceTarea(contenido);
                numero=aux.getNumeroTarea();
                contenido = lectura.readLine();
            }
        } catch (IOException excepcion) {
            numero=0;
        }
        
        if(numero!=0)
            return numero+1;
        else
            return 1;
    }
    /**
     * Cuenta el número total de tareas en la lista de tareas.
     *
     * @param direccion Ruta del archivo de la lista de tareas.
     * @return El número total de tareas.
     */
    public int tareasTotal(String direccion){
        int numero=0;
        File archivo=new File (direccion);
        String contenido="";
        
        try (BufferedReader lectura = new BufferedReader(new FileReader(archivo))) {
            contenido = lectura.readLine();
            while(contenido != null){
                numero++;
                contenido = lectura.readLine();
            }
        } catch (IOException excepcion) {
            numero=0;
        }
        return numero;
    }
    /**
     * Convierte una línea del archivo de lista de tareas en un objeto Tarea.
     *
     * @param contenido Línea del archivo que contiene los detalles de la tarea.
     * @return Objeto Tarea con los datos extraídos.
     */
    public Tarea indiceTarea(String contenido){
        int aux=0;
        int n=0;
        for(char c: contenido.toCharArray()){
            if(c=='|'){
                aux=n;
            }
            n++;
        }
        String nombre=contenido.substring(aux+1,contenido.length());
        String numero=contenido.substring(0,aux);
        int num=Integer.parseInt(numero);
        Tarea act = new Tarea (num,nombre,null,null,null,0,null);
        return act;
    }
    
   /**
     * Edita una tarea, modificando tanto la lista de tareas como el archivo correspondiente.
     *
     * @param direccion Ruta del archivo de la tarea a editar.
     * @param act Objeto Tarea con los nuevos detalles.
     * @param listaTareas Ruta del archivo donde se encuentra la lista de tareas.
     * @param ant Objeto Tarea con los detalles antiguos.
     */
    public void editarTarea(String direccion,Tarea act, String listaTareas, Tarea ant){
        String userHome = "E:\\GT";
        File archivo=new File(direccion);
        FileWriter escribir;
        PrintWriter linea;
        File ListaTareas=new File(listaTareas);
        String lineaEditar= ant.getNumeroTarea()+"|"+ant.getNombre();
        
        try {
            File archivoTemporal = new File(userHome + "E:\\GT\\Tareas\\auxiliar.txt");

            BufferedReader lector = new BufferedReader(new FileReader(ListaTareas));
            BufferedWriter escritor = new BufferedWriter(new FileWriter(archivoTemporal));

            String lineaActual;

            while ((lineaActual = lector.readLine()) != null) {
                if (!lineaActual.equals(lineaEditar)) {
                    escritor.write(lineaActual);
                    escritor.newLine();
                }else{
                    escritor.write(act.getNumeroTarea()+"|"+act.getNombre());
                    escritor.newLine();
                }
            }

            lector.close();
            escritor.close();
            //sacar del try sino funciona
            if (ListaTareas.delete()) {
                archivoTemporal.renameTo(ListaTareas);
                System.out.println("lista borrada exitosamente.");
            } else {
                System.out.println("No se pudo borrar el archivo.");
            }
            
            if (archivo.delete()) {
                System.out.println("Línea borrada exitosamente.");
            } else {
                System.out.println("No se pudo borrar el archivo.");
            }
            
            String direcTareas = userHome + "E:\\GT\\Tareas";
            act.CrearNuevaTarea(direcTareas, act);
            
            try {
            escribir = new FileWriter(archivo,true);
            linea = new PrintWriter(escribir);
            escribir.write("NumeroTarea:"+act.getNumeroTarea()+"\n");
            escribir.write("Nombre:"+act.getNombre()+"\n");
            escribir.write("Descripcion:"+act.getDescripcion()+"\n");
            escribir.write("Prioridad:"+act.getPrioridad()+"\n");
            escribir.write("Estado:"+act.getEstado()+"\n");
            escribir.write("UsuarioAsignado:"+act.getUsuarioAsignado()+"\n");
            escribir.write("Comentario:"+act.getComentario()+"\n");
            escribir.write("Dia:"+act.getDia()+"\n");
            escribir.write("Mes:"+act.getMes()+"\n");
            escribir.write("Año:"+act.getYear()+"\n");
            linea.close();
            
            } catch (IOException e) {
                System.out.println("Ocurrió un error al guardar la tarea: " + e.getMessage());
            }
        } catch (IOException e) {
            System.out.println("Ocurrió un error al intentar borrar la línea.");
            e.printStackTrace();
        }
    }
     /**
     * Edita una tarea especificada, eliminando la tarea anterior y creando una nueva.
     *
     * @param direccionTarea Ruta del archivo de la tarea a editar.
     * @param act Objeto Tarea con los nuevos detalles.
     * @param listaTareas Ruta del archivo donde se encuentra la lista de tareas.
     * @param ant Objeto Tarea con los detalles antiguos.
     * @param direc Ruta del directorio donde se almacenarán los archivos temporales.
     */
    public void editarCualquierTarea(String direccionTarea,Tarea act, String listaTareas, Tarea ant, String direc){
        String userHome = "E:\\GT";
        File archivo=new File(direccionTarea);
        FileWriter escribir;
        PrintWriter linea;
        File ListaTareas=new File(listaTareas);
        String lineaEditar= ant.getNumeroTarea()+"|"+ant.getNombre();
        
        try {
            File archivoTemporal = new File(direc+"\\auxiliar.txt");

            BufferedReader lector = new BufferedReader(new FileReader(ListaTareas));
            BufferedWriter escritor = new BufferedWriter(new FileWriter(archivoTemporal));

            String lineaActual;

            while ((lineaActual = lector.readLine()) != null) {
                if (!lineaActual.equals(lineaEditar)) {
                    escritor.write(lineaActual);
                    escritor.newLine();
                }else{
                    escritor.write(act.getNumeroTarea()+"|"+act.getNombre());
                    escritor.newLine();
                }
            }

            lector.close();
            escritor.close();
            //sacar del try sino funciona
            if (ListaTareas.delete()) {
                archivoTemporal.renameTo(ListaTareas);
                System.out.println("Línea borrada exitosamente.");
            } else {
                System.out.println("No se pudo borrar el archivo.");
            }
            
            if (archivo.delete()) {
                System.out.println("Línea borrada exitosamente.");
            } else {
                System.out.println("No se pudo borrar el archivo.");
            }
            
            act.CrearNuevaTarea(direc, act);
            
            try {
            escribir = new FileWriter(archivo,true);
            linea = new PrintWriter(escribir);
            escribir.write("NumeroTarea:"+act.getNumeroTarea()+"\n");
            escribir.write("Nombre:"+act.getNombre()+"\n");
            escribir.write("Descripcion:"+act.getDescripcion()+"\n");
            escribir.write("Prioridad:"+act.getPrioridad()+"\n");
            escribir.write("Estado:"+act.getEstado()+"\n");
            escribir.write("UsuarioAsignado:"+act.getUsuarioAsignado()+"\n");
            escribir.write("Comentario:"+act.getComentario()+"\n");
            escribir.write("Dia:"+act.getDia()+"\n");
            escribir.write("Mes:"+act.getMes()+"\n");
            escribir.write("Año:"+act.getYear()+"\n");
            linea.close();
            
            } catch (IOException e) {
                System.out.println("Ocurrió un error al guardar la tarea: " + e.getMessage());
            }
        } catch (IOException e) {
            System.out.println("Ocurrió un error al intentar borrar la línea.");
            e.printStackTrace();
        }
    }
    
    /**
     * Obtiene una lista de todas las tareas en el directorio especificado.
     *
     * @param direc Ruta del directorio que contiene la lista de tareas.
     * @return Una lista de objetos Tarea con todas las tareas encontradas.
     */
    public ArrayList<Tarea> ListaTareas(String direc) {
        File archivo = new File(direc + "\\ListaTareas.txt");
        String contenido = "";
        ArrayList<Tarea> act = new ArrayList<>(); // Cambiado de arreglo a ArrayList
        Tarea aux = new Tarea();

        try (BufferedReader lectura = new BufferedReader(new FileReader(archivo))) {
            contenido = lectura.readLine();
            while (contenido != null) {
                act.add(aux.indiceTarea(contenido)); // Usar add() para agregar al ArrayList
                contenido = lectura.readLine();
            }
        } catch (IOException excepcion) {
            excepcion.printStackTrace();
        }

        for (int ind = 0; ind < act.size(); ind++) {
            String direccion = direc + "\\" + act.get(ind).getNumeroTarea() + ".txt";
            act.set(ind, aux.DetallesTarea(direccion, act.get(ind).getNumeroTarea())); // Usar set() para actualizar elementos
        }

        return act;
    }
    
    /**
     * Obtiene la fecha de entrega de una tarea como un objeto Date.
     *
     * @return Fecha de entrega de la tarea.
     */
    public Date getFechaEntrega() {
        // Si el year es 0, usamos el año actual
        int yearToUse = (year != 0) ? year : java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);

        String monthStr = mes;
        int month = convertirMesAMesNumero(monthStr);  // Convierte el nombre del mes al número (enero = 1, febrero = 2, etc.)

        // Crea un objeto Date con el año proporcionado (o el actual), mes y día
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(yearToUse, month - 1, dia);  // Ajustamos el mes (0 = enero)
        return cal.getTime();
    }
/**
     * Convierte el nombre del mes a su número correspondiente.
     *
     * @param mes Nombre del mes (por ejemplo, "Enero", "Febrero").
     * @return El número correspondiente al mes (1 para Enero, 2 para Febrero, etc.).
     */
    private int convertirMesAMesNumero(String mes) {
        switch (mes) {
            case "Enero": return 1;
            case "Febrero": return 2;
            case "Marzo": return 3;
            case "Abril": return 4;
            case "Mayo": return 5;
            case "Junio": return 6;
            case "Julio": return 7;
            case "Agosto": return 8;
            case "Septiembre": return 9;
            case "Octubre": return 10;
            case "Noviembre": return 11;
            case "Diciembre": return 12;
            default: return 1; // Si el mes no es válido, asignamos enero por defecto.
        }
    }
}
